import { Component, OnInit } from '@angular/core';
import {Http, Response, Headers, RequestOptions} from "@angular/http";
import 'rxjs/add/operator/map';
import { Router, ActivatedRoute } from '@angular/router';
//import {Router, ActivatedRoute, Params} from '@angular/router';
import { Injectable } from '@angular/core';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  obj;
  params;
  persons=[];
  
  constructor(private http:Http,private router :Router, private ar:ActivatedRoute) { }

  ngOnInit() {
    
    this.ar.params.subscribe((res)=>{this.params = res});

    this.obj = new info();
    this.getinfo(this.params.uid);
  }
  
  getinfo(uid){
    var tousethisagaininprogram = this;
    this.http.get("http://localhost:3000/reg/"+uid)
    .map((givenresponse: Response)=> givenresponse.json())
    .subscribe(
      q=>
      {
        tousethisagaininprogram.obj=q;
        console.log(this.obj);
      })
  }


edit(uid)
{
  var instedofthis =this;
  var b= JSON.parse(JSON.stringify(this.obj));
  //if(b.id){put()}else{post()}
  this.http.put("http://localhost:3000/reg/"+uid,b)
  .subscribe(function(d)
  {
    console.log("data",d)
  instedofthis.router.navigate(['/show'])
  })
}


}

class info{
  public EID:string;
  public ENAME:any;
}
