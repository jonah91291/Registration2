import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit1',
  templateUrl: './edit1.component.html',
  styleUrls: ['./edit1.component.css']
})
export class Edit1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
